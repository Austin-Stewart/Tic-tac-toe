import game_board

boar = game_board.Board()
players_1 = game_board.Player()
players_2 = game_board.Player()
x = 0
while True:
    game_board.win(boar.list)
    cont = input("Continue Y/N")
    if cont.lower() == "y":
        choice = game_board.player_choice()
        boar.update_board(choice)
        boar.print_board()
        if x % 2 == 0:
            print(players_1.name + " chose " + choice[0] + " at " + choice[1])
            x = x+1
            print(x)
        elif x % 2 != 0:
            print(players_2.name + " chose " + choice[0] + " at " + choice[1])
            x += 1
            print(x)
    else:
        break
