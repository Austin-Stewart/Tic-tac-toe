def win(board):
    col = -1
    i = 0
    elems = []
    right = []
    columns = [1, 2, 3]
    col_row = -1
    for row in board:
        if row.count(row[0]) == len(row) and row[0] != " ":
            print("Winner!")
        elif row.count(row[1]) == len(row) and row[1] != " ":
            print("Winner!")
        elif row.count(row[2]) == len(row) and row[2] != " ":
            print("Winner!")
    for col in range(3):
        vertical = []
        for row in board:
            vertical.append(row[col])
        if vertical.count(vertical[0]) == len(vertical) and vertical[0] != " ":
            print("Winner!")
        "left diagonal"
    for row in board:
        elems.append(row[i])
        i += 1
        if elems.count(elems[0]) == len(elems) == 3 and elems[0] != " ":
            print("Winner")
        "right diagonal"
    for row in board:
        right.append(row[col])
        col -= 1
        if right.count(right[0]) == len(right) == 3 and right[0] != " ":
            print("Winner")


class Board:
    def __init__(self):
        self.list = [[" ", " ", " "],
                     [" ", " ", " "],
                     [" ", " ", " "]]

    def print_board(self):
        for element in self.list:
            print(element)

    def update_board(self, choice_location):

        if choice_location[0].lower() == "x" and choice_location[1] == "1,1":
            self.list[0][0] = "X"
        elif choice_location[0].lower() == "x" and choice_location[1] == "1,2":
            self.list[0][1] = "X"
        elif choice_location[0].lower() == "x" and choice_location[1] == "1,3":
            self.list[0][2] = "X"
        elif choice_location[0].lower() == "x" and choice_location[1] == "2,1":
            self.list[1][0] = "X"
        elif choice_location[0].lower() == "x" and choice_location[1] == "2,2":
            self.list[1][1] = "X"
        elif choice_location[0].lower() == "x" and choice_location[1] == "2,3":
            self.list[1][2] = "X"
        elif choice_location[0].lower() == "x" and choice_location[1] == "3,1":
            self.list[2][0] = "X"
        elif choice_location[0].lower() == "x" and choice_location[1] == "3,2":
            self.list[2][1] = "X"
        elif choice_location[0].lower() == "x" and choice_location[1] == "3,3":
            self.list[2][2] = "X"
        elif choice_location[0].lower() == "o" and choice_location[1] == "1,1":
            self.list[0][0] = "O"
        elif choice_location[0].lower() == "o" and choice_location[1] == "1,2":
            self.list[0][1] = "O"
        elif choice_location[0].lower() == "o" and choice_location[1] == "1,3":
            self.list[0][2] = "O"
        elif choice_location[0].lower() == "o" and choice_location[1] == "2,1":
            self.list[1][0] = "O"
        elif choice_location[0].lower() == "o" and choice_location[1] == "2,2":
            self.list[1][1] = "O"
        elif choice_location[0].lower() == "o" and choice_location[1] == "2,3":
            self.list[1][2] = "O"
        elif choice_location[0].lower() == "o" and choice_location[1] == "3,1":
            self.list[2][0] = "O"
        elif choice_location[0].lower() == "o" and choice_location[1] == "3,2":
            self.list[2][1] = "O"
        elif choice_location[0].lower() == "o" and choice_location[1] == "3,3":
            self.list[2][2] = "O"


def player_choice():
    choice = input("enter your choice x or o")
    location = input("Choose location in a row,column format")
    return [choice, location]


class Player:
    def __init__(self):
        self.name = input("What is your name")
